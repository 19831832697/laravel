<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use \App\models\Book;

class OrderController extends Controller
{
    public function list1(){
        echo 35435;
//        $data=Book::all();
//        print_r($data);
    }


















//    public function show(Request $request){
//        //控制器接收函数
//        $arr=$request->input();
//        print_r($arr);
//        //创建视图  控制器加载
//        return view('show');
//        //使用辅助函数url
//        $url=url('admin/msg');
//        return redirect($url);
//    }
//    public function msg(){
//        echo 2343534;
//    }
}
