<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $table="shop_cart";
    public $timestamps=false;
}
