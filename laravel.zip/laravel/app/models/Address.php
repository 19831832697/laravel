<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    protected $table="shop_order_address";
    public $timestamps=false;
}
