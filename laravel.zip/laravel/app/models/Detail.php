<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Detail extends Model
{
    protected $table="shop_order_detail";
}
